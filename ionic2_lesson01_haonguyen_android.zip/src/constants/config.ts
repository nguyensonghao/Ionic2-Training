export const API_URL = "http://api.test-jn.uat.pgtest.co/";
export const CURRENT_USER = 'currentUser';
export const SUCCESS_STATUS = 1;
export const ERROR_STATUS = 0;
export const APP_VERSION = "1.0.0";